package com.yash.ytdms.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yash.ytdms.dao.UserDAO;
import com.yash.ytdms.daoImpl.UserDAOImpl;

import com.yash.ytdms.domain.User;
import com.yash.ytdms.execption.UserException;
import com.yash.ytdms.service.UserService;
import com.yash.ytdms.util.DbUtils;
/**
 * this component is used implement all the business logic
 * @author samay.jain
 *
 */
public class UserServiceImpl extends DbUtils implements UserService {
	
	UserDAO userDao ;

	public UserServiceImpl() {
		userDao = new UserDAOImpl();
	}
	@Override
	public void register(User user) throws UserException {
		user.setRole(ROLE_TRAINER);
		user.setStauts(STATUS_ACTIVE);
		userDao.save(user);
		
	}
	
	@Override
	public User authenthicateUser(String loginId, String password) {
		String sql="SELECT * FROM users WHERE loginId =? AND PASSWORD=?";
		
		PreparedStatement pstmt = preparedStatement(sql);
		User loggedInUser =null;
		try {
			pstmt.setString(1,loginId);
			pstmt.setString(2,password);
			
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				loggedInUser = mapRow(rs);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return loggedInUser;
	}
	
	/**
	 * this method map the database row into a user object as a user if it is found in database
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private User mapRow(ResultSet rs) throws SQLException {
		User loggedInUser;
		loggedInUser =new User();
		loggedInUser.setName(rs.getString("name"));
		loggedInUser.setEmail(rs.getString("loginId"));
		loggedInUser.setPassword(rs.getString("password"));
		loggedInUser.setId(rs.getInt("id"));
		loggedInUser.setRole(rs.getInt("role"));
		loggedInUser.setStauts(rs.getInt("status"));
		return loggedInUser;
	}

	

}
