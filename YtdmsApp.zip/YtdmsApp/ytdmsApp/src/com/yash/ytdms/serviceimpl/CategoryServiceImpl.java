package com.yash.ytdms.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.yash.ytdms.dao.CategoryDAO;
import com.yash.ytdms.daoImpl.CategoryDAOImpl;
import com.yash.ytdms.domain.Category;
import com.yash.ytdms.service.CategoryService;
import com.yash.ytdms.util.DbUtils;

/**
 * this implement the business logic
 * @author samay.jain
 *
 */
public class CategoryServiceImpl extends DbUtils implements CategoryService {


	private CategoryDAO categoryDao;
	public CategoryServiceImpl() {
	categoryDao = new CategoryDAOImpl();
	}
	
	@Override
	public List<Category> listCategories() {
		
		List<Category> categories=  categoryDao.findAll();
		return categories;
	}

	@Override
	public void AddCategory(Category category) {
		category.setStatus(STATUS_ACTIVE);
		categoryDao.save(category);
		
	}

	@Override
	public void DeleteCategory(int categoryId) {
		categoryDao.delete(categoryId);
		
	}

	@Override
	public Category ShowCategoryDetails(int catergoryId) {
		String sql ="SELECT * from categories where id="+catergoryId+"";
		Category category = null ;
		PreparedStatement pstmt = preparedStatement(sql);
		try {
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				category= new Category();
				category.setId(rs.getInt("id"));
				category.setUserId(rs.getInt("userId"));
				category.setName(rs.getString("name"));
				category.setDescription(rs.getString("description"));
				category.setStatus(rs.getInt("status"));
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return category;
		
	}

	@Override
	public void EditCategory(Category category) {
		String sql="UPDATE categories SET NAME = ?, description = ? WHERE id=?";
		PreparedStatement pstmt =preparedStatement(sql);
		
		try {
			pstmt.setString(1,category.getName());
			pstmt.setString(2, category.getDescription());
			pstmt.setInt(3,category.getId());
			pstmt.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
