package com.yash.ytdms.dao;

import java.util.List;

import com.yash.ytdms.domain.Category;

/**
 * this component is used to declare all the crud operation of category
 * such as - save, update, list, delete 
 * @author samay.jain
 *
 */

public interface CategoryDAO {



	/**
	 * this method is used to save a new category in the database
	 * @param user which is to be entered in the database
	 */ 
	void save(Category category);
	
	/**
	 * used to get the list of all users in the database
	 * @return list of users
	 */
	List<Category> findAll();
	
	/**
	 * this method is used to update the user 
	 * @param user which needed to be updated
	 */
	void update(Category category);
	
	/**
	 * this method is used to delete a user from database
	 * @param user which is going to be remove from database
	 */
	void delete(Category category);
	
	void delete (int categoryId);
}


