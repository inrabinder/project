package com.yash.ytdms.execption;

/**
 * this component is to throws the user exceptions
 * @author samay.jain
 *
 */
public class UserException extends Exception {

	public UserException() {
		super();
	}
	
	public UserException(String Errmsg) {
		super(Errmsg);
	}
	
	
}
