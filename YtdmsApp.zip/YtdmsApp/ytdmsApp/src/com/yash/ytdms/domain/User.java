package com.yash.ytdms.domain;

/**
 * This user domain works as data traveller from layer to layer
 * this will represent the user record in database
 * @author samay.jain
 *
 */
public class User {
	/**
	 * this the unique id of the user
	 */
	private int id;
	/**
	 * this is the name of the user
	 */
	private String name;
	
	/**
	 * this is the mail id of the user
	 */
	private String email;
	/**
	 * this the login id of the user
	 */
	private String loginId;
	/**
	 * this is the password of the user
	 */
	private String password;
	/**
	 * this is the role of the user
	 * 1 - Admin
	 * 2 - Trainer manager
	 * 3 - Trainer
	 */
	private int role;
	/**
	 * this is the status of the user 
	 * 1 -active
	 * 2- block
	 */
	private int stauts;
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getLoginId() {
		return loginId;
	}
	
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public int getRole() {
		return role;
	}
	
	public void setRole(int role) {
		this.role = role;
	}
	
	public int getStauts() {
		return stauts;
	}
	
	public void setStauts(int stauts) {
		this.stauts = stauts;
	}
	
	
}
