package com.yash.ytdms.test;

import com.yash.ytdms.dao.CategoryDAO;
import com.yash.ytdms.daoImpl.CategoryDAOImpl;
import com.yash.ytdms.domain.Category;
import com.yash.ytdms.serviceimpl.CategoryServiceImpl;

public class CategoryTesting {

	public static void main(String[] args) {
		CategoryServiceImpl categoryService = new  CategoryServiceImpl();
		System.out.println( categoryService.ShowCategoryDetails(13));
//		System.out.println(category);

	}

}
