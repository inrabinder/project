package com.yash.ytdms.test;


import java.util.List;

import com.yash.ytdms.dao.CategoryDAO;
import com.yash.ytdms.daoImpl.CategoryDAOImpl;
import com.yash.ytdms.domain.Category;
import com.yash.ytdms.service.CategoryService;
import com.yash.ytdms.serviceimpl.CategoryServiceImpl;
import com.yash.ytdms.util.DbUtils;

/**
 * use for testing data base connectivity and its operation 
 * @author samay.jain
 *
 */
public class DbUtilConnectionTest extends DbUtils {
	 public static void main(String[] args) {
//		 Category category = new  Category();
		 
		 CategoryDAO categoryDAO =new  CategoryDAOImpl();		
		 CategoryService categoryService = new CategoryServiceImpl();
		 List<Category> categories  = categoryService.listCategories();
//		 List<Category> categories = categoryDAO.finalAll();
		System.out.println(categories);
	}


}
