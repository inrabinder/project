package com.yash.ytdms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.ytdms.domain.Category;
import com.yash.ytdms.service.CategoryService;
import com.yash.ytdms.serviceimpl.CategoryServiceImpl;

/**
 * Servlet implementation class ShowDetailsController
 */
@WebServlet("/edit")
public class ShowDetailsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CategoryService categoryService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowDetailsController() {
        super();
        categoryService = new CategoryServiceImpl();
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		int categoryId = Integer.parseInt(request.getParameter("id"));
		Category category = categoryService.ShowCategoryDetails(categoryId);
		session.setAttribute("categoryId",category.getId());
		session.setAttribute("category",category);
		response.sendRedirect("edit.jsp");
		
	}

}
