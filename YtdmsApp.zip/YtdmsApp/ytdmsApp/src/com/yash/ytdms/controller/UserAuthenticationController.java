package com.yash.ytdms.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.ytdms.domain.User;
import com.yash.ytdms.service.UserService;
import com.yash.ytdms.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class UserAuthenticationController
 */
@WebServlet("/UserAuthenticationController")
public class UserAuthenticationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private UserService userService;

//	private CategoryService categoryService;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserAuthenticationController() {
		super();
		userService = new UserServiceImpl();
//		categoryService =  new CategoryServiceImpl();

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User loggedInUser = new User();
		loggedInUser = userService.authenthicateUser(request.getParameter("loginId"), request.getParameter("password"));
		if (loggedInUser != null) {
			HttpSession session = request.getSession();
			session.setAttribute("loggedInUserId", loggedInUser.getId());
			session.setAttribute("loggedInUserRole", loggedInUser.getRole());
			session.setAttribute("loggedInUser", loggedInUser);
			getServletContext().getRequestDispatcher("/CategoryPreparationController").forward(request, response);

		} else {
			response.sendRedirect("login.jsp?errmsg=invalid username or password");
		}
	}
}
