package com.yash.ytdms.daoImpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.ytdms.dao.CategoryDAO;
import com.yash.ytdms.domain.Category;
import com.yash.ytdms.util.DbUtils;

public class CategoryDAOImpl extends DbUtils implements CategoryDAO {

	@Override
	public void save(Category category) {
		String sql="INSERT INTO categories (userId, NAME,description,STATUS) VALUE(?,?,?,?)";
		PreparedStatement pstmt= preparedStatement(sql);
		try {
			pstmt.setInt(1, category.getUserId());
			pstmt.setString(2, category.getName());
			pstmt.setString(3, category.getDescription());
			pstmt.setInt(4, category.getStatus());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Category> findAll() {
		List<Category> categories =new ArrayList<>();
		Category category = null;
		String sql="Select * from categories";
		PreparedStatement pstmt=  preparedStatement(sql);
		try {
			ResultSet rs= pstmt.executeQuery();
			while(rs.next()) {
				category =new Category();
				category.setId(rs.getInt("id"));
				category.setUserId(rs.getInt("userId"));
				category.setName(rs.getString("name"));
				category.setDescription(rs.getString("description"));
				category.setStatus(rs.getInt("status"));
				categories.add(category);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return categories;
	}

	@Override
	public void update(Category category) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Category category) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(int categoryId) {
		String sql ="DELETE FROM categories WHERE id="+categoryId+"";
		try {
			preparedStatement(sql).execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
