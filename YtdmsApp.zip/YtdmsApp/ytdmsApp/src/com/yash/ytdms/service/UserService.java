package com.yash.ytdms.service;


import com.yash.ytdms.domain.User;
import com.yash.ytdms.execption.UserException;
/**
 * This component is used to declare all the business logic 
 * @author samay.jain
 *
 */
public interface UserService {
	
	int ROLE_ADMIN = 1;
	int ROLE_TRAINER_MANAGER = 2;
	/**
	 * default role
	 */
	int ROLE_TRAINER= 3;
	
	/**
	 * default status
	 */
	int STATUS_ACTIVE= 1;
	int STATUS_BLOCK= 2;
	
	
	/**
	 * this method is used to register a new user in the system 
	 * if the user is already present then give appropriate error message 
	 * @throws UserException 
	 */
	void register (User user) throws UserException;
	
	/**
	 * used to check the user is authenthicate or not 
	 * @param username 
	 * @param password
	 * @return authenticated user
	 */ 
	User authenthicateUser(String username,String password);
}
