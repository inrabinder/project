package com.yash.ytdms.service;

import java.util.List;

import com.yash.ytdms.domain.Category;

/**
 * this competent is used for business logic implementation 
 * @author samay.jain
 *
 */
public interface CategoryService {
	
	int STATUS_ACTIVE=1;
	int  STATUS_BLOCKED=1;

	/**
	 * give list of all category
	 * @return
	 */
	List<Category> listCategories();
	
	/**
	 * this method is used to add a new category in the system
	 * @param category to be added
	 */
	void AddCategory (Category category);
	
	/**
	 *  this method is used to delete the category
	 * @param Id of the category to be deleted
	 */
	void DeleteCategory(int categoryId);
	
	/**
	 * this method is to the categoryDetails
	 * @param Id of the category to show 
	 */
	Category ShowCategoryDetails(int catergoryId);
	
	/**
	 * this method is used to edit the category
	 * @param categoryId of the category to edit
	 */
	void EditCategory(Category category);
}
