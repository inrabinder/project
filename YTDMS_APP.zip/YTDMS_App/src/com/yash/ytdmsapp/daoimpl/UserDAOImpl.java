package com.yash.ytdmsapp.daoimpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.yash.ytdmsapp.dao.UserDAO;
import com.yash.ytdmsapp.domain.User;
import com.yash.ytdmsapp.util.DBUtil;
/**
 * This UserDAOImpl is implementation of UserDAO  
 * @author rajpal.dodiya
 *
 */
public class UserDAOImpl extends DBUtil implements UserDAO{

	@Override
	public void save(User user) {
		String sql=null;
		sql="insert into users(name,email,loginId,password,role,status)values(?,?,?,?,?,?)";
		PreparedStatement preparedStatement=prepareStatement(sql);
		try
		{
		preparedStatement.setString(1, user.getName());
		preparedStatement.setString(2, user.getEmail());
		preparedStatement.setString(3, user.getLoginId());
		preparedStatement.setString(4, user.getPassword());
		preparedStatement.setInt(5,TRAINER);
		preparedStatement.setInt(6, ACTIVE_USER);
		preparedStatement.execute();
		}catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
		}
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(User user) {
		// TODO Auto-generated method stub
		
	}

}
