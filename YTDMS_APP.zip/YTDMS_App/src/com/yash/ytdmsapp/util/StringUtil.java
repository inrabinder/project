package com.yash.ytdmsapp.util;

public class StringUtil {
private static StringBuilder stringBuilder;
public static boolean stringValidator(String inputString,int length)
{
return (inputString.length()<=length);
}
}
