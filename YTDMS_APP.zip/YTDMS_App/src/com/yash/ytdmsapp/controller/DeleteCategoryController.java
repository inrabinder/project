package com.yash.ytdmsapp.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.ytdmsapp.service.CategoryService;
import com.yash.ytdmsapp.serviceimpl.CategoryServiceImpl;

/**
 * Servlet implementation class DeleteCategoryController
 */
@WebServlet("/delete")
public class DeleteCategoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private CategoryService categoryService;
	public DeleteCategoryController() {
     categoryService=new CategoryServiceImpl();
}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int categoryId=Integer.parseInt(request.getParameter("id"));
		categoryService.deleteCategory(categoryId);
		getServletContext().getRequestDispatcher("/CategoryPreparationController").forward(request, response);
	}

}
