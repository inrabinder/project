package com.yash.ytdmsapp.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.xml.internal.resolver.readers.OASISXMLCatalogReader;
import com.yash.ytdmsapp.domain.User;
import com.yash.ytdmsapp.exception.UserException;
import com.yash.ytdmsapp.service.UserService;
import com.yash.ytdmsapp.serviceimpl.UserServiceImpl;
/**
 * This is controller 
 * it will create a model
 * and redirect to the view.
 * @author rajpal.dodiya
 *
 */

@WebServlet("/UserRegistrationController")

public class UserRegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private UserService userService;   
    
    public UserRegistrationController() {
        super();
        userService=new UserServiceImpl();
    }

		protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			User user=new User();
			String email=request.getParameter("email");
			String loginId=request.getParameter("loginId");
			String name=request.getParameter("name");
			String password=request.getParameter("password");
			user.setEmail(email);
			user.setLoginId(loginId);
			user.setName(name);
			user.setPassword(password);
			try {
				
				userService.registerUser(user);
				
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		response.sendRedirect("login.jsp");

}
}