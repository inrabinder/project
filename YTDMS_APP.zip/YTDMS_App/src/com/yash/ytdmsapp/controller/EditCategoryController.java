package com.yash.ytdmsapp.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.ytdmsapp.domain.Category;
import com.yash.ytdmsapp.service.CategoryService;
import com.yash.ytdmsapp.serviceimpl.CategoryServiceImpl;

/**
 * Servlet implementation class EditCategoryController
 */
@WebServlet("/edit")
public class EditCategoryController extends HttpServlet {
	private CategoryService categoryService;
    public EditCategoryController() {
        super();
        categoryService=new CategoryServiceImpl();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int categoryId=Integer.parseInt(request.getParameter("id"));
		Category category=new Category();
		category.setId(categoryId);
		category=categoryService.editCategory(category,0);
		if(category!=null)
		{	HttpSession httpSession=request.getSession();
			httpSession.setAttribute("category",category);
			response.sendRedirect("editCategory.jsp");
		}
		else
		{
			response.sendRedirect("index.jsp");
		}
	}

	
}
