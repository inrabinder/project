package com.yash.ytdmsapp.test;

import java.sql.SQLException;

import com.yash.ytdmsapp.util.DBUtil;

public class DBUtilTest{

	public static void main(String[] args) throws SQLException {
				DBUtil dbUtil=new DBUtil();
				dbUtil.connect();
	}

}
