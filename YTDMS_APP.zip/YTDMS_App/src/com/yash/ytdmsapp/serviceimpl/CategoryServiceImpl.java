package com.yash.ytdmsapp.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import com.yash.ytdmsapp.dao.CategoryDAO;
import com.yash.ytdmsapp.daoimpl.CategoryDAOImpl;
import com.yash.ytdmsapp.domain.Category;
import com.yash.ytdmsapp.service.CategoryService;
import com.yash.ytdmsapp.util.DBUtil;

public class CategoryServiceImpl extends DBUtil implements CategoryService{
private CategoryDAO categoryDAO=null;
	public CategoryServiceImpl() {
		categoryDAO=new CategoryDAOImpl();
	}
	@Override
	public List<Category> listAll() {
		List<Category>categories;
		categories=categoryDAO.findAll();
		return categories;
	}
public void addCategory(Category category)
{
	String sql="insert into categories(name,userId,status,description) values(?,?,?,?)";
	PreparedStatement preparedStatement= prepareStatement(sql);
	try
	{
		
		preparedStatement.setString(1, category.getName());
		preparedStatement.setInt(2, category.getUserId());
		preparedStatement.setInt(3, category.getStatus());
		preparedStatement.setString(4, category.getDescription());
		preparedStatement.execute();
		
	}catch(SQLException sqlException)
	{
		sqlException.printStackTrace();
	}
}
public void deleteCategory(int categoryId)
{
	categoryDAO.delete(categoryId);
}

@Override
public Category editCategory(Category category,int operation) {
	if(operation==0)
	{
		return edit(category.getId());
	}
	else
	{
      categoryDAO.update(category);
      return null;
	}
	
}


private Category edit(int categoryId)
{
	Category category=null;
    String sql="select *from categories where id=?";
    PreparedStatement preparedStatement=prepareStatement(sql);
    try
    {
    preparedStatement.setInt(1, categoryId);
    ResultSet resultSet=preparedStatement.executeQuery();
    if(resultSet.next())
    {
    	category=new Category();
    	category.setDescription(resultSet.getString("description"));
    	category.setId(resultSet.getInt("id"));
    	category.setName(resultSet.getString("name"));
    	category.setStatus(resultSet.getInt("status"));
    	category.setUserId(resultSet.getInt("userId"));
    }
    }
    catch(SQLException sqlException)
    {
    sqlException.printStackTrace();
    }
	return category;
}
public List<Category> searchByCategoryName(String parameter)
{
	String sql="select *from categories where name=?";
	PreparedStatement preparedStatement=prepareStatement(sql);
	List<Category>categories=new LinkedList<Category>();
	Category category=null;
	try
	{
		preparedStatement.setString(1,parameter);
		ResultSet resultSet=preparedStatement.executeQuery();
		
		while(resultSet.next())
		{
		category=new Category();
		category.setDescription(resultSet.getString("description"));
		category.setId(resultSet.getInt("id"));
		category.setName(resultSet.getString("name"));
		category.setStatus(resultSet.getInt("status"));
		category.setUserId(resultSet.getInt("userId"));
		categories.add(category);
		
		}
		
		
	}
	catch(SQLException sqlException)
	{
		sqlException.printStackTrace();
	}
return categories;
}
}