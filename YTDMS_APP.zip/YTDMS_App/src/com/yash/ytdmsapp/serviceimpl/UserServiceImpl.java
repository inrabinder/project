package com.yash.ytdmsapp.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yash.ytdmsapp.dao.UserDAO;
import com.yash.ytdmsapp.daoimpl.UserDAOImpl;
import com.yash.ytdmsapp.domain.User;
import com.yash.ytdmsapp.exception.UserException;
import com.yash.ytdmsapp.service.UserService;
import com.yash.ytdmsapp.util.DBUtil;

public class UserServiceImpl extends DBUtil implements UserService {
private UserDAO userDAO;

public UserServiceImpl()
{
	userDAO=new UserDAOImpl();
}

@Override
	public void registerUser(User user)throws UserException {
		//check from database for user existence
		userDAO.save(user);
	}

	@Override
	public User authenticateUser(String loginId, String password) {
		String sql="select *from users where loginId=? AND password=?";
		PreparedStatement preparedStatement=prepareStatement(sql);
		User loggedInUser=null;
		try
		{
		preparedStatement.setString(1,loginId);
		preparedStatement.setString(2,password);
		ResultSet resultSet=preparedStatement.executeQuery();
		if(resultSet.next())
		{
			loggedInUser=new User();
			loggedInUser.setEmail(resultSet.getString("email"));
			loggedInUser.setId(resultSet.getInt("id"));
			loggedInUser.setLoginId(resultSet.getString("loginId"));
			loggedInUser.setName(resultSet.getString("name"));
			loggedInUser.setPassword(resultSet.getString("password"));
			loggedInUser.setRole(resultSet.getInt("role"));
			loggedInUser.setStatus(resultSet.getInt("status"));
		}
		}catch(SQLException sqlException)
		{
				
		}
		return loggedInUser;
	}

}
