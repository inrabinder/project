package com.yash.ytdms.dao;

import java.util.List;

import com.yash.ytdms.domain.Category;
/**
 * This interfaces defines all the crud operation of the category
 * @author YIINTERN01
 *
 */

public interface CategoryDAO {
	/**
	 * This method will find all the data of categories from the database
	 * @return
	 */
	List<Category> findAll();
	void changeStatus(int id, int visibilityStatus);

}
