package com.yash.ytdms.serviceimpl;

import java.util.List;


import com.yash.ytdms.dao.CategoryDAO;
import com.yash.ytdms.daoimpl.CategoryDAOImpl;
import com.yash.ytdms.domain.Category;
import com.yash.ytdms.service.CategoryService;
/**
 * This class is implementation of the CategoryServiceInterface.
 * @author YIINTERN01
 *
 */

public class CategoryServiceImpl implements CategoryService {
	private CategoryDAO categoryDao;
	public CategoryServiceImpl() {
		categoryDao=new CategoryDAOImpl();
	}
/**
 * This method returns the all the category details of each of the category
 */
	@Override
	public List<Category> listCategories() {
		return categoryDao.findAll();
		
		
	}
@Override
public void changeVisbilityStatus(int id, int visibilityStatus) {
	if(visibilityStatus==ACTIVE) {
		categoryDao.changeStatus(id, BLOCKED);
	}
	else if(visibilityStatus==BLOCKED) {
		categoryDao.changeStatus(id,ACTIVE);
	}
	
}

}
