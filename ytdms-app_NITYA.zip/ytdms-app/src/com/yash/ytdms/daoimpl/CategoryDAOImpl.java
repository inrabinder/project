package com.yash.ytdms.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.ytdms.dao.CategoryDAO;
import com.yash.ytdms.domain.Category;

import com.yash.ytdms.util.JNDIUtil;
/**
 * This class provides implementation of  crud operation 
 * @author YIINTERN01
 *
 */

public class CategoryDAOImpl extends JNDIUtil implements CategoryDAO {

	@Override
	/**
	 * This method findAll() finds all record of the category from the database
	 */
	public List<Category> findAll() {
		
		{
			Category category=null;
			String sql="select * from categories order by id DESC ";
			List<Category> categories=new ArrayList<Category>();
			try {
				PreparedStatement preparedStatement=preparedStatement(sql);
				ResultSet rs= preparedStatement.executeQuery();
				while(rs.next()) {
					 category=new Category();
			category.setId(rs.getInt("id"));
			category.setName(rs.getString("name"));
			category.setDescription(rs.getString("description"));
			category.setCreation_date(rs.getDate("creation_date"));
			category.setVisibility_status(rs.getInt("visibility_status"));
			category.setPermission_status(rs.getInt("permission_status"));
			categories.add(category);
				}
			}
			catch (SQLException e) {
				
				e.printStackTrace();
			}
			
			return categories;
		}
	}

	@Override
	public void changeStatus(int id, int visibilityStatus) {
		String sql="update categories set visibility_status=? where id=?";
		try {
		PreparedStatement preparedStatement= preparedStatement(sql);
		preparedStatement.setInt(1, visibilityStatus);
		preparedStatement.setInt(2, id);
		preparedStatement.execute();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}

}
