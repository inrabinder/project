package com.yash.ytdms.domain;

import java.util.Date;

/**
 * This class describes the properties of each Category
 * @author YIINTERN01
 *
 */

public class Category {
	/**
	 * Category Id defines the id of each category
	 * This is a primary key and auto incremented 
	 */
	 private int id;
	 /**
	  * Name defines the name of each category
	  */
	 private String name;
	 /**
	  * Description of the category defines here.
	  */

	 private String description;
	 /**
	  * Creation date describes the date on which a category is created
	  */
	 private Date creation_date;
	 /**
	  * This defines the visibility of the category
	  * It can either be ACTIVE or BLOCK
	  */
	 private int visibility_status;
	 /**
	  * This defines the permission of the category
	  * It can either be APPROVED,PENDING or REJECT
	  */
	 private int permission_status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getCreation_date() {
		return creation_date;
	}
	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}
	public int getVisibility_status() {
		return visibility_status;
	}
	public void setVisibility_status(int visibility_status) {
		this.visibility_status = visibility_status;
	}
	public int getPermission_status() {
		return permission_status;
	}
	public void setPermission_status(int permission_status) {
		this.permission_status = permission_status;
	}
	 
	 

}
