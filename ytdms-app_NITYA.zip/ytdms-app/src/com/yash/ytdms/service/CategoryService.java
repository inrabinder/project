package com.yash.ytdms.service;

import java.util.List;

import com.yash.ytdms.domain.Category;
/**
 * This interface have all the methods where we add our bussiness logic
 * @author YIINTERN01
 *
 */

public interface CategoryService {
	public static int ACTIVE=1;
	public static int BLOCKED=2;
	/**
	 * This method will list all the categories .
	 * @return it will return the list of categories.
	 */
	
	 public List<Category> listCategories();
	 
	 void changeVisbilityStatus(int id, int visibilityStatus);

}
