package com.yash.ytdms.test;


import java.util.ArrayList;
import java.util.List;

import com.yash.ytdms.domain.Category;
import com.yash.ytdms.service.CategoryService;
import com.yash.ytdms.serviceimpl.CategoryServiceImpl;

public class Category_finAllOperationCheckTest {

	public static void main(String[] args) {
	CategoryService categoryService=new CategoryServiceImpl();
	List<Category> arrayList=categoryService.listCategories();
	for (Category category : arrayList) {
		System.out.println(category.getId());
		System.out.println(category.getName());
		System.out.println(category.getDescription());
		System.out.println(category.getCreation_date());
		System.out.println(category.getVisibility_status());
		System.out.println(category.getPermission_status());
	}
	

	}

}
