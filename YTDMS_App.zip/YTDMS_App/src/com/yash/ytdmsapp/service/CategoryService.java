package com.yash.ytdmsapp.service;

import java.util.List;

import com.yash.ytdmsapp.domain.Category;

/**
 * This CategoryService will contain all the business logics related to Category
 * @author rajpal.dodiya
 *
 */
public interface CategoryService {
public List<Category>listAll();
public void addCategory(Category category);
public void deleteCategory(int categoryId);
public Category editCategory(Category category,int operation);
}
