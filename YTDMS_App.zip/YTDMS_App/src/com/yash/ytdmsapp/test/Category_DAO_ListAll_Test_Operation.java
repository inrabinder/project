package com.yash.ytdmsapp.test;

import com.yash.ytdmsapp.dao.CategoryDAO;
import com.yash.ytdmsapp.daoimpl.CategoryDAOImpl;

public class Category_DAO_ListAll_Test_Operation {

	public static void main(String[] args) {
		CategoryDAO categoryDAO=new CategoryDAOImpl();
		System.out.println(categoryDAO.findAll());

	}

}
