package com.yash.ytdmsapp.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import com.yash.ytdmsapp.dao.CategoryDAO;
import com.yash.ytdmsapp.domain.Category;
import com.yash.ytdmsapp.util.DBUtil;
/**
 * This CategoryDAOImpl is implementation of CategoryDAO  
 * @author rajpal.dodiya
 *
 */
public class CategoryDAOImpl extends DBUtil implements CategoryDAO{

	@Override
	public void save(Category category) {
		
	}

	@Override
	public List<Category> findAll() {
		List<Category> categories=new LinkedList<>();
		Category category;
		String sql="select *from categories";
		PreparedStatement preparedStatement=prepareStatement(sql);
		try
		{
		ResultSet resultSet=preparedStatement.executeQuery();
		while(resultSet.next())
		{
			category=new Category();
			category.setDescription(resultSet.getString("description"));
			category.setId(resultSet.getInt("id"));
			category.setName(resultSet.getString("name"));
			category.setStatus(resultSet.getInt("status"));
			category.setUserId(resultSet.getInt("userId"));
			categories.add(category);
		}
		}
		catch(SQLException sqlException)
		{
			
		}
		
		return categories;
	}

	@Override
	public void update(Category category) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Category category) {
		// TODO Auto-generated method stub
		
	}
	public void delete(int categoryId)
	{
		String sql="delete from categories where id=?";
		PreparedStatement preparedStatement=prepareStatement(sql);
		try
		{
			preparedStatement.setInt(1, categoryId);
			preparedStatement.execute();
		}catch(SQLException sqlException)
		{
			
		}
	}

		

}

