package com.yash.ytdmsapp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.ytdmsapp.domain.Category;
import com.yash.ytdmsapp.domain.User;
import com.yash.ytdmsapp.service.CategoryService;
import com.yash.ytdmsapp.service.UserService;
import com.yash.ytdmsapp.serviceimpl.CategoryServiceImpl;
import com.yash.ytdmsapp.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class UserAuthenticationServlet
 */
@WebServlet("/UserAuthenticationServlet")
public class UserAuthenticationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private UserService userService=null;
    
    public UserAuthenticationServlet() {
        super();
        userService =new UserServiceImpl();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	User loggedInUser=userService.authenticateUser(request.getParameter("loginId"),request.getParameter("password"));
	if(loggedInUser!=null)
	{
		HttpSession httpSession=request.getSession();
		httpSession.setAttribute("loggedInUserId", loggedInUser.getId());
		httpSession.setAttribute("loggedInUserRole",loggedInUser.getRole());
		httpSession.setAttribute("loggedInUser",loggedInUser);
		getServletContext().getRequestDispatcher("/CategoryPreparationController").forward(request, response);
	}
	else
	{
		response.sendRedirect("login.jsp");
	}
	}

}
