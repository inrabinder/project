package com.yash.ytdmsapp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.ytdmsapp.domain.Category;
import com.yash.ytdmsapp.service.CategoryService;
import com.yash.ytdmsapp.serviceimpl.CategoryServiceImpl;


@WebServlet("/CategoryPreparationController")
public class CategoryPreparationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CategoryService categoryService=null;
    
    public CategoryPreparationController() {
        super();
        categoryService=new CategoryServiceImpl();
    }
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession httpSession=request.getSession();
    	List<Category>categories;
		categories=categoryService.listAll();
		httpSession.setAttribute("categories",categories);
		response.sendRedirect("index.jsp");
    }

	
	
}
